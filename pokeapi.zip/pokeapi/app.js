// Obtener referencias a elementos HTML
const fetchBtn = document.getElementById('fetchBtn'); // Botón para obtener datos del Pokémon
const pokemonDataContainer = document.getElementById('pokemonData'); // Contenedor para mostrar datos del Pokémon

// Agregar un evento de clic al botón de obtener datos
fetchBtn.addEventListener('click', fetchPokemonData);

// Función para obtener datos de un Pokémon
function fetchPokemonData() {
    // Generar un ID de Pokémon aleatorio entre 1 y 898 (el número total de Pokémon disponibles)
    const pokemonId = Math.floor(Math.random() * 898) + 1;

    // Construir la URL de la API de PokeAPI usando el ID del Pokémon
    const apiUrl = `https://pokeapi.co/api/v2/pokemon/${pokemonId}`;

    // Realizar una solicitud de fetch a la API de PokeAPI
    fetch(apiUrl)
        .then(response => {
            // Verificar si la respuesta es exitosa
            if (!response.ok) {
                // Lanzar un error si la respuesta no es exitosa
                throw new Error(`Failed to fetch Pokémon data (${response.status})`);
            }
            // Convertir la respuesta a JSON y devolverla
            return response.json();
        })
        .then(data => {
            // Llamar a la función para mostrar los datos del Pokémon
            displayPokemonData(data);
        })
        .catch(error => {
            // Capturar cualquier error que ocurra durante la solicitud
            console.error('Error fetching Pokémon data:', error.message);
        });
}

// Función para mostrar los datos del Pokémon en el contenedor HTML
function displayPokemonData(pokemon) {
    // Actualizar el contenido del contenedor HTML con los datos del Pokémon
    pokemonDataContainer.innerHTML = `
        <h2>${pokemon.name}</h2>
        <img src="${pokemon.sprites.front_default}" alt="${pokemon.name}">
        <p>Type: ${pokemon.types.map(type => type.type.name).join(', ')}</p>
        <p>Abilities: ${pokemon.abilities.map(ability => ability.ability.name).join(', ')}</p>
    `;
}
